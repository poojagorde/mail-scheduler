let config = {
    WWW_PORT: (process.env.PORT || 8080),
    user_URL: (process.env.user_URL || "http://localhost:8020/"),
    task_URL: (process.env.task_URL || "http://localhost:8010/")
}

module.exports= config