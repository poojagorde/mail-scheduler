const express= require('express');
const httpProxy = require('http-proxy-middleware')
const config= require('./config')

let taskProxy;
let UserProxy;


let app= express();

app.use('/hello',(req,res)=>{
    res.send("Welcoem to My gateWay")
})

taskProxy=httpProxy.createProxyMiddleware({
    target: config.task_URL,
    pathRewrite:{'^/taskService':'/'}
})
app.use('/taskService/',taskProxy)

UserProxy=httpProxy.createProxyMiddleware({
    target: config.user_URL,
    pathRewrite:{'^/userService':'/'}
})
app.use('/userService/',UserProxy)

app.use((req,res)=>{
    res.status(404).send({messgae:"Resource Not Found......"})
})


module.exports= app;