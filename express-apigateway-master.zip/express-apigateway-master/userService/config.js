let config = {
    WWW_PORT: (process.env.PORT || 8020)
}

module.exports= config