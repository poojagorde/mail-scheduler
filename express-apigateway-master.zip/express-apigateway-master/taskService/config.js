let config = {
    WWW_PORT: (process.env.PORT || 8010)
}

module.exports= config